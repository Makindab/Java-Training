// Do not modify this file!

class Test01 {
    public static void main(String[] args) {
        var p = new Point(2, 4);
        System.out.println("The coordinates are: " + p.x + ", " + p.y);

        p.x = 1.0;
        p.y = 2.0;
        System.out.println("The coordinates are now: " + p.x + ", " + p.y);
    }
}
