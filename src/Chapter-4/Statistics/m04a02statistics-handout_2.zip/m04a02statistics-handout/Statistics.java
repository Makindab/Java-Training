class Statistics {
    // Write your code here
}
