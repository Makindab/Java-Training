// Do not modify this file!

class Test01 {
    public static void main(String[] args) {
        var c = new Car("FIAT", "Topolino", "EZ 13623", "blue");

        System.out.println("The car brand is: " + c.brand);
        System.out.println("The car model is: " + c.model);
        System.out.println("The car number plate is: " + c.numberPlate);
        System.out.println("The car color is: " + c.color);
    }
}
