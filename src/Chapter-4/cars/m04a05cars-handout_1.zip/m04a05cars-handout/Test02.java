// Do not modify this file!

class Test02 {
    public static void main(String[] args) {
        var c1 = new Car("Ford", "Fiesta", "AF 54539", "red");
        var c2 = new Car("FIAT", "Topolino", "EZ 13623", "blue");

        System.out.println("Car 1: " + c1.toString());
        System.out.println("Car 2: " + c2.toString());
    }
}
