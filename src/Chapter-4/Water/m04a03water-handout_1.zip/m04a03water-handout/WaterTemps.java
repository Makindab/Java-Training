class WaterTemps {
    // Write your code here
}
