// Do not modify this file!

class Test01 {
    public static void main(String[] args) {
        var arr1 = new int[] {4, 1, 2, 3};
        var arr2 = new int[] {1, 3};

        ArrayTestUtils.test(arr1, arr2);
    }
}
