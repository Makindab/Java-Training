class ArrayUtils {
    public static boolean contains(int[] arr1, int[] arr2) {
        // Write your code here
    }
}
