// Do not modify this file!

class Test02 {
    public static void main(String[] args) {
        var d1 = new Departure(10, 25, "Aarhus");
        var d2 = new Departure(9, 33, "Roskilde");
        var d3 = new Departure(9, 55, "Aalborg");
        var d4 = new Departure(13, 45, "Odense");
        var d5 = new Departure(17, 22, "Esbjerg");

        System.out.println(d1.toString());
        System.out.println(d2.toString());
        System.out.println(d3.toString());
        System.out.println(d4.toString());
        System.out.println(d5.toString());
    }
}
