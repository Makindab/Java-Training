class Departure {
    // Write your code here
}
