class ArrayUtils {
    // Write your code here
}
