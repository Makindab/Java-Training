// Do not modify this file!

class Test02 {
    public static void main(String[] args) {
        var arr1 = new int[] {4, 1, 2, 3};
        var arr2 = new int[] {3, 1};

        ArrayTestUtils.test(arr1, arr2);
    }
}
