class Utils {
    static String createSquare(int size) {
        // Write your code here
    }
}
