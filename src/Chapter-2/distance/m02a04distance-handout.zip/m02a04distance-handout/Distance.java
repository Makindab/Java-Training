class Distance {
    public static void main(String[] args) {
        // Write your code here
    }
}
